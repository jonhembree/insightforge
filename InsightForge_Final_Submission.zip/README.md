# InsightForge AI BI System

## Author
**Jon Hembree**

## Structure
- backend/: Python scripts for data analysis
- ui/: Frontend (React + Tailwind)
- docs/: Project documentation PDF
- example_data/: Sample Excel input
